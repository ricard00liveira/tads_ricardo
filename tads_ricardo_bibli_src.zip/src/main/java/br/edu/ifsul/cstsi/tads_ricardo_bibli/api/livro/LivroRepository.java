package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.livro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository extends JpaRepository<Livro, Long> {
}
