package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.autenticacao;

public record UsuarioAutenticacaoDTO(String usuario, String senha) {
}
