package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.artigo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ArtigoRepository extends JpaRepository<Artigo, Long> {
}