package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.emprestimo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {
}
