package br.edu.ifsul.cstsi.tads_ricardo_bibli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TadsRicardoBibliApplication {

    public static void main(String[] args) {
        SpringApplication.run(TadsRicardoBibliApplication.class, args);
    }

}
