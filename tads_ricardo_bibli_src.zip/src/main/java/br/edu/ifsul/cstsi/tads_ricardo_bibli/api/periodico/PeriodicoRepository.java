package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.periodico;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PeriodicoRepository extends JpaRepository<Periodico, Long> {
}
