package br.edu.ifsul.cstsi.tads_ricardo_bibli.api.paidealuno;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PaiDeAlunoRepository extends JpaRepository<PaiDeAluno, Long> {
}