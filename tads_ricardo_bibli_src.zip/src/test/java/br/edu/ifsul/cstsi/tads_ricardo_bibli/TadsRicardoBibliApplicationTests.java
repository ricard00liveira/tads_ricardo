package br.edu.ifsul.cstsi.tads_ricardo_bibli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TadsRicardoBibliApplicationTests {

    @Test
    void contextLoads() {
    }

}
